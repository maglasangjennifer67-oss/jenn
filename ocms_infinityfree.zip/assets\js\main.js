/**
 * ResolveX - Online Complaint Management System
 * Front-end interactivity and validations
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. Bootstrap 5 Form Validation
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // 2. Auto-dismiss alerts after 5 seconds
    const autoDismissAlerts = document.querySelectorAll('.alert-dismissible');
    autoDismissAlerts.forEach(function (alert) {
        setTimeout(function () {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) {
                bsAlert.close();
            }
        }, 5000);
    });

    // 3. Dynamic Delete Confirmation Modal Population
    const deleteModal = document.getElementById('deleteConfirmModal');
    if (deleteModal) {
        deleteModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const complaintId = button.getAttribute('data-id');
            const trackingCode = button.getAttribute('data-tracking');
            const subject = button.getAttribute('data-subject');

            const idInput = deleteModal.querySelector('#delete_complaint_id');
            const trackingSpan = deleteModal.querySelector('#delete_tracking_code');
            const subjectSpan = deleteModal.querySelector('#delete_subject');

            if (idInput) idInput.value = complaintId;
            if (trackingSpan) trackingSpan.textContent = trackingCode;
            if (subjectSpan) subjectSpan.textContent = subject;
        });
    }

    // 4. Copy Tracking Code to Clipboard
    window.copyToClipboard = function (text, btnElement) {
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).then(showCopiedTooltip).catch(fallbackCopy);
        } else {
            fallbackCopy();
        }

        function showCopiedTooltip() {
            const originalHTML = btnElement.innerHTML;
            btnElement.innerHTML = '<i class="bi bi-check2"></i> Copied!';
            btnElement.classList.replace('btn-outline-secondary', 'btn-success');
            setTimeout(function () {
                btnElement.innerHTML = originalHTML;
                btnElement.classList.replace('btn-success', 'btn-outline-secondary');
            }, 2000);
        }

        function fallbackCopy() {
            const textArea = document.createElement("textarea");
            textArea.value = text;
            textArea.style.position = "fixed";
            textArea.style.left = "-9999px";
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            try {
                document.execCommand('copy');
                showCopiedTooltip();
            } catch (err) {
                alert('Tracking code: ' + text);
            }
            document.body.removeChild(textArea);
        }
    };
});
