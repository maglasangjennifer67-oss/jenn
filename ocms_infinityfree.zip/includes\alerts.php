<?php
// includes/alerts.php
if (function_exists('getFlash')) {
    $flash = getFlash();
    if ($flash) {
        $alertType = $flash['type'] ?? 'info';
        $alertMsg  = $flash['message'] ?? '';
        
        $icon = 'info-circle';
        if ($alertType === 'success') $icon = 'check-circle-fill';
        if ($alertType === 'danger')  $icon = 'exclamation-triangle-fill';
        if ($alertType === 'warning') $icon = 'exclamation-circle-fill';
        ?>
        <div class="alert alert-<?= htmlspecialchars($alertType) ?> alert-dismissible fade show shadow-sm d-flex align-items-center mb-4" role="alert">
            <i class="bi bi-<?= $icon ?> fs-4 me-2"></i>
            <div class="flex-grow-1">
                <?= $alertMsg ?>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php
    }
}
?>
