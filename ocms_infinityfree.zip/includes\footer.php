        </div><!-- /.container -->
    </main>

    <!-- Global Footer -->
    <footer class="mt-auto">
        <div class="container">
            <div class="row g-4 mb-4">
                <div class="col-lg-4 col-md-6">
                    <h5 class="text-white fw-bold mb-3 d-flex align-items-center gap-2">
                        <i class="bi bi-shield-check text-primary"></i> ResolveX OCMS
                    </h5>
                    <p class="small text-muted mb-3">
                        A robust, transparent, and responsive online complaint management system engineered with PHP & MySQL. Track, resolve, and monitor grievances with end-to-end accountability.
                    </p>
                    <div class="d-flex gap-2 text-white">
                        <span class="badge bg-secondary">PHP 8+</span>
                        <span class="badge bg-secondary">MySQL / PDO</span>
                        <span class="badge bg-secondary">Bootstrap 5</span>
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-6">
                    <h6 class="text-white fw-semibold mb-3">Quick Navigation</h6>
                    <ul class="list-unstyled small mb-0">
                        <li class="mb-2"><a href="index.php"><i class="bi bi-chevron-right me-1"></i> Home</a></li>
                        <li class="mb-2"><a href="submit-complaint.php"><i class="bi bi-chevron-right me-1"></i> File Complaint</a></li>
                        <li class="mb-2"><a href="track-complaint.php"><i class="bi bi-chevron-right me-1"></i> Track Status</a></li>
                        <li class="mb-2"><a href="manage-complaints.php"><i class="bi bi-chevron-right me-1"></i> Admin Portal</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6">
                    <h6 class="text-white fw-semibold mb-3">Status Categories</h6>
                    <ul class="list-unstyled small mb-0">
                        <li class="mb-2"><span class="badge badge-status badge-pending">Pending</span> Initial review queue</li>
                        <li class="mb-2"><span class="badge badge-status badge-in-progress">In Progress</span> Department assigned</li>
                        <li class="mb-2"><span class="badge badge-status badge-resolved">Resolved</span> Action taken & solved</li>
                        <li class="mb-2"><span class="badge badge-status badge-closed">Closed</span> Archived & finalized</li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6">
                    <h6 class="text-white fw-semibold mb-3">Support & Hosting</h6>
                    <p class="small text-muted mb-2">
                        Designed for seamless deployment on <strong>InfinityFree Free Web Hosting</strong> and local development via <strong>XAMPP</strong>.
                    </p>
                    <div class="small text-muted">
                        <i class="bi bi-envelope me-1"></i> support@resolvex.local<br>
                        <i class="bi bi-clock me-1"></i> 24/7 Incident Logging
                    </div>
                </div>
            </div>

            <hr class="border-secondary opacity-25 my-3">

            <div class="row align-items-center small">
                <div class="col-md-6 text-center text-md-start mb-2 mb-md-0">
                    &copy; <?= date('Y') ?> ResolveX Online Complaint Management System. All rights reserved.
                </div>
                <div class="col-md-6 text-center text-md-end text-muted">
                    Built with Bootstrap 5.3 & PHP MySQL PDO
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap 5.3.3 JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom Application JS -->
    <script src="assets/js/main.js"></script>
</body>
</html>
