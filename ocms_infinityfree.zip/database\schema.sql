-- ==============================================================================
-- Online Complaint Management System (OCMS) Database Schema
-- Compatible with MySQL 5.7+ / MariaDB 10.4+ (XAMPP & InfinityFree)
-- ==============================================================================

CREATE DATABASE IF NOT EXISTS `ocms_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `ocms_db`;

-- Drop existing tables if re-importing
DROP TABLE IF EXISTS `complaints`;
DROP TABLE IF EXISTS `categories`;

-- ------------------------------------------------------------------------------
-- Table 1: categories (Reference table for complaint types)
-- ------------------------------------------------------------------------------
CREATE TABLE `categories` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL UNIQUE,
    `description` VARCHAR(255) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default categories
INSERT INTO `categories` (`name`, `description`) VALUES
('Technical Support', 'Issues related to website, software bugs, portal logins, and network connectivity.'),
('Billing & Payments', 'Discrepancies in invoices, payment gateway errors, and refund requests.'),
('Customer Service', 'Feedback regarding agent behavior, response time, and communication quality.'),
('Facility & Infrastructure', 'Physical facilities, maintenance, power, hardware, and safety issues.'),
('Academic / Administrative', 'Course registration, grading queries, documentation, and office requests.'),
('General Inquiry / Others', 'Other uncategorized grievances and general inquiries.');

-- ------------------------------------------------------------------------------
-- Table 2: complaints (Main CRUD table with 12 distinct fields)
-- ------------------------------------------------------------------------------
CREATE TABLE `complaints` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `tracking_code` VARCHAR(25) NOT NULL UNIQUE,
    `complainant_name` VARCHAR(100) NOT NULL,
    `email` VARCHAR(120) NOT NULL,
    `phone` VARCHAR(25) NOT NULL,
    `category` VARCHAR(100) NOT NULL,
    `priority` ENUM('Low', 'Medium', 'High', 'Urgent') NOT NULL DEFAULT 'Medium',
    `subject` VARCHAR(200) NOT NULL,
    `description` TEXT NOT NULL,
    `status` ENUM('Pending', 'In Progress', 'Resolved', 'Closed') NOT NULL DEFAULT 'Pending',
    `admin_remarks` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_tracking_code` (`tracking_code`),
    INDEX `idx_status` (`status`),
    INDEX `idx_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- Seed sample records for demonstration and instant testing
-- ------------------------------------------------------------------------------
INSERT INTO `complaints` 
(`tracking_code`, `complainant_name`, `email`, `phone`, `category`, `priority`, `subject`, `description`, `status`, `admin_remarks`, `created_at`) 
VALUES
('CMP-2026-1001', 'Juan Dela Cruz', 'juan.delacruz@example.com', '09171234567', 'Technical Support', 'High', 'Unable to access online dashboard after password reset', 'After requesting a password reset yesterday, the activation link expired immediately. I cannot log in to submit my quarterly documents.', 'In Progress', 'Assigned to IT security team. Temporary reset token generated.', '2026-11-10 09:30:00'),
('CMP-2026-1002', 'Maria Santos', 'maria.santos@example.com', '09189876543', 'Billing & Payments', 'Urgent', 'Double charge on transaction REF-8892', 'My credit card was debited twice for transaction REF-8892 on Nov 8. I have attached the bank statement screenshot in my follow up email.', 'Resolved', 'Finance verified the duplicate payment. Refund of $45.00 processed back to credit card on Nov 11.', '2026-11-08 14:15:00'),
('CMP-2026-1003', 'Carlos Garcia', 'carlos.garcia@example.com', '09205551234', 'Customer Service', 'Low', 'Long hold time with telephone support representative', 'Waited for over 35 minutes before reaching an agent on Thursday afternoon. Need more staff during peak afternoon hours.', 'Closed', 'Apology issued to complainant. Call center scheduling has been adjusted for peak hours.', '2026-11-05 16:45:00'),
('CMP-2026-1004', 'Elena Rodriguez', 'elena.r@example.com', '09224447890', 'Facility & Infrastructure', 'Medium', 'Air conditioning unit leaking water in Conference Room 3B', 'The ceiling AC unit above row 2 is dripping water onto the presentation table and carpeting.', 'Pending', NULL, '2026-11-13 11:20:00');
