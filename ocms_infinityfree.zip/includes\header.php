<?php
// includes/header.php
if (!defined('APP_INIT')) {
    require_once __DIR__ . '/../config/database.php';
    define('APP_INIT', true);
}

// Current page detection for active nav highlights
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) . ' - ' : '' ?>ResolveX | Online Complaint Management System</title>
    
    <!-- Google Fonts: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5.3.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons 1.11.3 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

    <!-- Responsive Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom sticky-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-2" href="index.php">
                <span class="badge bg-primary p-2 rounded-3">
                    <i class="bi bi-shield-check fs-5"></i>
                </span>
                <span>Resolve<span class="text-primary">X</span></span>
            </a>
            
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain" aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarMain">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-3">
                    <li class="nav-item">
                        <a class="nav-link <?= ($currentPage === 'index.php') ? 'active' : '' ?>" href="index.php">
                            <i class="bi bi-house-door me-1"></i> Home
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($currentPage === 'submit-complaint.php') ? 'active' : '' ?>" href="submit-complaint.php">
                            <i class="bi bi-plus-circle me-1"></i> Submit Complaint
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($currentPage === 'track-complaint.php') ? 'active' : '' ?>" href="track-complaint.php">
                            <i class="bi bi-search me-1"></i> Track Status
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= in_array($currentPage, ['manage-complaints.php', 'edit-complaint.php', 'view-complaint.php']) ? 'active' : '' ?>" href="manage-complaints.php">
                            <i class="bi bi-speedometer2 me-1"></i> Complaints Dashboard
                        </a>
                    </li>
                </ul>
                <div class="d-flex align-items-center gap-2">
                    <a href="submit-complaint.php" class="btn btn-primary btn-sm px-3 shadow-sm d-flex align-items-center gap-1">
                        <i class="bi bi-pencil-square"></i> File a Complaint
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content Wrapper -->
    <main class="py-4">
        <div class="container">
            <?php require_once __DIR__ . '/alerts.php'; ?>
