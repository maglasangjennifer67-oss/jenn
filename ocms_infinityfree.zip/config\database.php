<?php
/**
 * Database Configuration & PDO Connection
 * Online Complaint Management System (OCMS)
 * 
 * Supports both Local Development (XAMPP) and Production Hosting (InfinityFree).
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Determine if running locally (XAMPP) or on remote host (InfinityFree)
$isLocal = in_array($_SERVER['SERVER_NAME'] ?? 'localhost', ['localhost', '127.0.0.1', '::1']) || php_sapi_name() === 'cli';

if ($isLocal) {
    // ==========================================
    // 1. LOCAL XAMPP CONFIGURATION
    // ==========================================
    define('DB_HOST', 'sql210.infinityfree.com');
    define('DB_PORT', '3306');
    define('DB_NAME', 'if0_43438189_ocms_db');
    define('DB_USER', 'if0_43438189');
    define('DB_PASS', 'jenni200601');
} else {
    // ==========================================
    // 2. INFINITYFREE HOSTING CONFIGURATION
    // Fill in your InfinityFree MySQL details below
    // Found in: InfinityFree Control Panel -> MySQL Databases
    // ==========================================
    define('DB_HOST', 'sql210.infinityfree.com'); // e.g., sql302.epizy.com or sql101.infinityfree.com
    define('DB_PORT', '3306');
    define('DB_NAME', 'if0_43438189_ocms_db');    // e.g., epiz_12345678_ocms_db
    define('DB_USER', 'if0_43438189');            // e.g., epiz_12345678
    define('DB_PASS', 'jenni200601');    // Your InfinityFree account/vPanel password
}

/**
 * Returns a singleton PDO connection
 *
 * @return PDO
 */
function getDbConnection(): PDO {
    static $pdo = null;

    if ($pdo === null) {
        $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_PORT, DB_NAME);
        
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
        ];

        // If local, automatically try port 3306 then fallback to 3307 if needed
        $portsToTry = [DB_PORT];
        if (in_array(DB_HOST, ['127.0.0.1', 'localhost'])) {
            $portsToTry = array_unique([DB_PORT, '3306', '3307']);
        }

        $lastException = null;
        foreach ($portsToTry as $port) {
            $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', DB_HOST, $port, DB_NAME);
            try {
                $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
                break; // Connection succeeded!
            } catch (PDOException $e) {
                $lastException = $e;
            }
        }

        if ($pdo === null && $lastException !== null) {
            $e = $lastException;
            // Do not emit 500 status code so browser will render the visual diagnostic message
            ?>
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>Database Connection Error - OCMS</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
            </head>
            <body class="bg-light d-flex align-items-center min-vh-100">
                <div class="container" style="max-width: 680px;">
                    <div class="card shadow-sm border-danger">
                        <div class="card-header bg-danger text-white py-3">
                            <h5 class="mb-0 fw-bold">Database Connection Error</h5>
                        </div>
                        <div class="card-body p-4">
                            <p class="text-danger fw-semibold">Failed to connect to MySQL database:</p>
                            <div class="bg-light p-3 rounded border text-muted small font-monospace mb-3">
                                <?= htmlspecialchars($e->getMessage()) ?>
                            </div>
                            <h6 class="fw-bold">How to resolve:</h6>
                            <ul class="small text-muted">
                                <li><strong>If using XAMPP (Local):</strong> Make sure the <code>MySQL</code> module is started in the XAMPP Control Panel and you have imported <code>database/schema.sql</code> in phpMyAdmin (<code>http://localhost/phpmyadmin</code>).</li>
                                <li><strong>If using InfinityFree:</strong> Check <code>config/database.php</code> and verify your <code>DB_HOST</code>, <code>DB_NAME</code>, <code>DB_USER</code>, and <code>DB_PASS</code> match your InfinityFree MySQL Databases panel.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </body>
            </html>
            <?php
            exit;
        }
    }

    return $pdo;
}

/**
 * Helper function to sanitize user inputs for display (XSS defense)
 */
function sanitize($data): string {
    return htmlspecialchars(trim((string)$data), ENT_QUOTES, 'UTF-8');
}

/**
 * Generate a unique human-friendly complaint tracking code
 * e.g. CMP-2026-8742
 */
function generateTrackingCode(): string {
    $year = date('Y');
    $random = strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));
    return "CMP-{$year}-{$random}";
}

/**
 * Set a flash alert message into session
 */
function setFlash(string $type, string $message): void {
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'danger', 'warning', 'info'
        'message' => $message
    ];
}

/**
 * Retrieve and clear flash alert message
 */
function getFlash(): ?array {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}
